package composite;

public interface InterfataComunaNoduri {
      public void descriere();
}
