package flyweight;

public interface IPacient {
    public void printarePacient(Spitalizare spitalizare);
}
