package proxy;

public interface ISpital {
	public void internare(Persoana pacient);
}
