package tests.dubluri;

import acs.ase.clase.IPersoana;

public class PersoanaStub implements IPersoana{

	@Override
	public String getSex() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getVarsta() {
		// TODO Auto-generated method stub
		return 65;
	}

	@Override
	public boolean checkCNP() {
		// TODO Auto-generated method stub
		return false;
	}

}
