package interfaces;

public interface IPersoanaTanaraTest {

}
