package interfaces;

public interface IPersoanaVarstnicaTest {

}
