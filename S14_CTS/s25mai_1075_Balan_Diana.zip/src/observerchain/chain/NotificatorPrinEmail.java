package observerchain.chain;

public class NotificatorPrinEmail {

}
