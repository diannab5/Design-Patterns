package observerchain.chain;

import observer.Observer;

public class NotificatorPrinSMS extends Handler{

	@Override
	public void notificaClient(Observer client,String mesaj) {
         
	}

}
