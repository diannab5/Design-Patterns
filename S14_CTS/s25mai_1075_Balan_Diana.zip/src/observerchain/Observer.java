package observerchain;

public interface Observer {
   public void receptioneazaMesaj(String mesaj);
  public String getNrTelefon();
  public String getEmail();
  public String getNume();

}
