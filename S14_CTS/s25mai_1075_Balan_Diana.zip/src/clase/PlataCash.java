package clase;

public class PlataCash implements ModPLata {

	@Override
	public void realizeazaPlata(float suma) {
      System.out.println("Suma " + suma + "a fost platita cash");
	}

}
