package clase;

public class PlataCard implements ModPLata {

	@Override
	public void realizeazaPlata(float suma) {
	      System.out.println("Suma " + suma + "a fost platita cu cardul ");
	
	}

}
