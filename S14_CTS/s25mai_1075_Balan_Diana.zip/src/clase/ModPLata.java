package clase;

//Strategy
public interface ModPLata {
  public void realizeazaPlata(float suma);
}
