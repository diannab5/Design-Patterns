package observer;

public interface Observer {
   public void receptioneazaMesaj(String mesaj);
}
