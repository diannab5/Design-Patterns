package adapter.framework_existent;

public interface Credit {
   public void oferaCredit();
   public float rataLunara();
}
