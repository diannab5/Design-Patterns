package decorator;

public interface IBonDeCasa {
     public void printBon();
}
