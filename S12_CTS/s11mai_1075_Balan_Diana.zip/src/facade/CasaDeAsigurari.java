package facade;

public class CasaDeAsigurari {
      public static boolean esteAsigurat(int nrCard) {
    	  return nrCard%2==1;
      }
}
