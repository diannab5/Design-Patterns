package facade;

public class Reteta {
     private int codMedicament;
     private int nrCard;
	public Reteta(int codMedicament, int nrCard) {
		super();
		this.codMedicament = codMedicament;
		this.nrCard = nrCard;
	}
	public int getCodMedicament() {
		return codMedicament;
	}
	public int getNrCard() {
		return nrCard;
	}
     
     
     
     
}
