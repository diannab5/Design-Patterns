package tests;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;

import org.junit.Test;

import acs.ase.clase.Persoana;

public class TestPersoana {
	
	@Test
	public void testVarstaRight() {
		Persoana pers=new Persoana("Irina","2861202154852");
		assertEquals("Varsta nu este cea asteptata" , 33,pers.getVarsta());
	}
	
	@Test
	public void testVarstaRight2000() {
		Persoana pers=new Persoana("Ioana","5120513154852");
		assertEquals("Varsta nu este cea asteptata" , 7,pers.getVarsta());
	}
	
	@Test
	public void testVarstaBounderyInferior1900() {
		Persoana pers=new Persoana("Alex","2000101025482");
		assertEquals(120, pers.getVarsta());
	}
	
	@Test
	public void testVarstaBounderySuperior1999() {
		Persoana pers=new Persoana("Teo","1991231456347");
		assertEquals(20, pers.getVarsta());
	}
	
	@Test
	public void testVarstaBounderySuperior2000() {
		Persoana pers=new Persoana("Marius","5200323456879");
		assertEquals(0, pers.getVarsta());
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCheckVarstaError() {
		Persoana pers=new Persoana("Alexandra","9983315078912");
	    pers.getVarsta();
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCheckSuperior2000Error() {
		Calendar dataCurenta=Calendar.getInstance();
		String CNP="5"+(dataCurenta.get(Calendar.YEAR)-2000)+(dataCurenta.get(Calendar.MONTH)+1)+(dataCurenta.get(Calendar.DAY_OF_MONTH)+1)+"546789";
		Persoana pers=new Persoana("Alexandra",CNP);
	    pers.getVarsta();
	}
	@Test(timeout=10)//milisecunde
	public void testgetVarstaTimp() {
		Persoana persoana=new Persoana("Mara","2980315132346");
		persoana.getVarsta();
	}
}