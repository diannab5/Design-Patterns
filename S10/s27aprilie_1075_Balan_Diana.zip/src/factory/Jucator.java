package factory;

public interface Jucator {
	public String getNamePlayer();
	public String getPosition();
}
