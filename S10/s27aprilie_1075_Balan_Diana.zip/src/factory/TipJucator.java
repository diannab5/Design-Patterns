package factory;

public enum TipJucator {
	PORTAR,
	FUNDAS,
	ATACANT
}
